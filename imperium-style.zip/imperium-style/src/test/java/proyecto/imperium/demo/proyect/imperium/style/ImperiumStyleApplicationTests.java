package proyecto.imperium.demo.proyect.imperium.style;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImperiumStyleApplicationTests {

	@Test
	void contextLoads() {
	}

}

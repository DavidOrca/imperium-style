package proyecto.imperium.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import proyecto.imperium.demo.models.Reserva;
import proyecto.imperium.demo.Service.ReservaService;

import java.util.Collections;
import java.util.Map;

@Controller
public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    @GetMapping("/agendar")
    public String agendar(Model model) {
        model.addAttribute("reservas", reservaService.obtenerTodasLasReservas());
        return "agendar";
    }

    @GetMapping("/reservas/{reservaId}")
    @ResponseBody
    public ResponseEntity<Reserva> obtenerReservaPorId(@PathVariable Long reservaId) {
        return reservaService.obtenerReservaPorId(reservaId)
                .map(reserva -> ResponseEntity.ok(reserva))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/reservas/agregar")
    @ResponseBody
    public ResponseEntity<Map<String, String>> agregarOEditarReserva(Reserva reserva) {
        if (reservaService.esReservaValida(reserva)) {
            reservaService.guardarReserva(reserva);
            return ResponseEntity.ok(Collections.singletonMap("message", "Reserva agregada exitosamente"));
        } else {
            return ResponseEntity.badRequest().body(Collections.singletonMap("message", "No puedes hacer una reserva dentro de los 15 minutos de otra reserva."));
        }
    }


    // Suponiendo que quieres eliminar reservas mediante una solicitud POST
    @PostMapping("/reservas/eliminar/{reservaId}")
    public String eliminarReserva(@PathVariable Long reservaId) {
        reservaService.eliminarReserva(reservaId);
        return "redirect:/agendar";
    }

}

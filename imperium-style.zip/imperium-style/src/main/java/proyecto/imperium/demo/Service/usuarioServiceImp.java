package proyecto.imperium.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proyecto.imperium.demo.models.Usuario;
import proyecto.imperium.demo.repo.UsuarioRepo;

import java.util.List;
import java.util.Optional;

@Service
public class usuarioServiceImp implements usuarioService {

    @Autowired
    private UsuarioRepo data;

    @Override
    public List<Usuario> listAllUsers() {
        return data.findAll();
    }

    @Override
    public Optional<Usuario> getUsuarioById(Integer id) {
        return Optional.empty();
    }
}

package proyecto.imperium.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import proyecto.imperium.demo.models.Reserva;

import java.time.LocalDateTime;
import java.util.List;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    // En ReservaRepository.java
    List<Reserva> findByFechaHoraBetween(LocalDateTime inicio, LocalDateTime fin);
}

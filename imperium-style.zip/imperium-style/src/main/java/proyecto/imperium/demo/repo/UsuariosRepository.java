package proyecto.imperium.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import proyecto.imperium.demo.models.Usuarios;
import java.util.Optional;

public interface UsuariosRepository extends JpaRepository<Usuarios, Integer> {
    Optional<Usuarios> findByEmail(String email);
}
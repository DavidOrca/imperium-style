package proyecto.imperium.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proyecto.imperium.demo.models.Reserva;
import proyecto.imperium.demo.repo.ReservaRepository;
import java.time.LocalDateTime;

import java.util.List;
import java.util.Optional;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    // Obtener todas las reservas
    public List<Reserva> obtenerTodasLasReservas() {
        return reservaRepository.findAll();
    }

    // Obtener una reserva por ID
    public Optional<Reserva> obtenerReservaPorId(Long id) {
        return reservaRepository.findById(id);
    }

    // Guardar o actualizar una reserva
    public Reserva guardarReserva(Reserva reserva) {
        return reservaRepository.save(reserva);
    }

    // Eliminar una reserva
    public void eliminarReserva(Long id) {
        reservaRepository.deleteById(id);
    }

    public boolean esReservaValida(Reserva reservaPropuesta) {
        LocalDateTime inicio = reservaPropuesta.getFechaHora().minusMinutes(15);
        LocalDateTime fin = reservaPropuesta.getFechaHora().plusMinutes(15);

        List<Reserva> reservasSolapadas = reservaRepository.findByFechaHoraBetween(inicio, fin);

        // Si la reserva propuesta tiene un ID, excluye esa reserva de la lista de reservas solapadas
        if (reservaPropuesta.getId() != null) {
            reservasSolapadas.removeIf(reserva -> reserva.getId().equals(reservaPropuesta.getId()));
        }

        // Si no hay reservas solapadas, la reserva propuesta es válida
        return reservasSolapadas.isEmpty();
    }


    // Otros métodos que puedas necesitar relacionados con las reservas...

}
